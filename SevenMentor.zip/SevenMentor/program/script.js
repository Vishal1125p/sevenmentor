var classroom=setInterval(classroom,450)
var career=setInterval(career,-2000)
var Mentors=setInterval(Mentors,400)
var onof=setInterval(onof,200)



var count1=1;
var count2=1;
var count3=1;
var count4=1;

function classroom(){
    count1++
    document.querySelector('#fifty').innerHTML=count1
        if(count1==50){
            clearInterval(classroom)
    }
  
}
function career(){
    count2++
    document.querySelector('#seventytwo').innerHTML=count2
    if(count2==72000){
            clearInterval(career)
    }
}
function Mentors(){
    count3++
    document.querySelector('#Mentors').innerHTML=count3
    if(count3==72){
            clearInterval(Mentors)
    }
}
function onof(){
    count4++
    document.querySelector('#on-of-co').innerHTML=count4
        if(count4==200){
            clearInterval(onof)
    }
  
}

let slideIndex=1;
showSlides(slideIndex)

function plusSlides(n){
    showSlides(slideIndex+=n)
    // slideIndex=slideIndex+1
}
function currentSlide(n){
    showSlides(slideIndex=n)
}

function showSlides(n){
    let i;
    let slides=document.getElementsByClassName('card')
    let dots=document.getElementsByClassName('dot')
    if(n>slides.length){
        slideIndex=1
    }
    if(n<1){
        slideIndex=slides.length
    }
    for(i=0;i<slides.length;i++){
        slides[i].style.display="none"
    }
    for(i=0;i<dots.length;i++){
        dots[i].className=dots[i].className.replace("active","")
    }
    slides[slideIndex-1].style.display="flex";
    dots[slideIndex-1].className +="active"
}



